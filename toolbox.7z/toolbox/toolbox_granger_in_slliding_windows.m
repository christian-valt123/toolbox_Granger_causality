%%%%
% the import file in brainstorm should have 
% 1) two identical concatenated data of all the artifacts-free trials for each condition of interest
% 2) a kernel of source-level activity

current_folder = pwd;

% ENTER
% the brainstorm data folder to be used
img = imread('front_page.png');

check_x = 0;

% show entry figure
%figure('Units', 'pixels', 'Position', get(0, 'ScreenSize')); % Get the screen size
h = figure('Visible', 'off');  % Create a figure, set it to 'off' to hide the window
imshow(img);
axis off;  % Hide the axis

% Make the figure visible
set(h, 'Visible', 'on');

pause(2);

% Close the figure after 2 seconds
close(h);
    
while check_x == 0
    % this variable serves to wait for a response in the last prompt
    timing = 0;

    prompt = {'path to brainstorm data folder (string):',...
         'subject to analyze (number or matlab concatentation experession)',...
         'position of the imported folder counted from the bottom position (number):',...
         'trial name (string):',...
         'starting time point (number):',...
         'length of the segment in ms (number):',...
         'sliding time-window interval (number):',...
         'number of time windows (number):',...
         'max frequency (number):',...
         'order (number):'};
    dlgtitle = 'Input';
    definput= {'H:/XX/XX/data',...
        'enter 0 for all the subjects or specify the sequence numer [1,2,3] or [1:3,5]',...
        'enter 1 if there is only one folder of imported data',...
        'example: deviant_stimuli',...
        '-100',...
        '100',...
        '10',...
        '10',...
        '30',...
        '10'};

    fieldsize = [1 100;1 100;1 100;1 45;1 45;1 45;1 45;1 45;1 45;1 45];
    answer = inputdlg(prompt,dlgtitle,fieldsize,definput);


    data_folder = cell2mat(answer(1,1));
    subjects2analyze = eval(cell2mat(answer(2,1)));
    position_folder = str2double(cell2mat(answer(3,1)))-1; % here, to get to the real last trial and move from there
    trial_name = cell2mat(answer(4,1));
    starting = str2double(cell2mat(answer(5,1)));
    length_of_time_windows = str2double(cell2mat(answer(6,1)));
    jumps = str2double(cell2mat(answer(7,1)));
    n_time_windows = str2double(cell2mat(answer(8,1)));
    max_freq = str2double(cell2mat(answer(9,1)));
    order2use = str2double(cell2mat(answer(10,1)));

    % ENTER 
    % the atlas and scouts 

    list = {'Destrieux','Desikan-Killiany','Broadmann','cluster'};
    [indx,tf] = listdlg('ListString',list,'SelectionMode','single');
    altas = cell2mat(list(indx));

    if indx == 1
        load('atlas/scout_Destrieux_148')
    elseif indx == 2
        load('atlas/scout_Desikan-Killiany_68')
    elseif indx == 3
        load('atlas/scout_Brodmann_26') 
    elseif indx == 4
        load('atlas/scout_cluster_4')     
    end

    list2 = {Scouts.Label};
    [indx2,tf2] = listdlg('ListString',list2);

    regions = cellstr(list2(indx2));

    % concatenates the names of all parcellations into a single string
    regions_cell = cell(size(indx2,2),2);
    for i = 1 : size(indx2,2)
        regions_cell(i,1:2) = cellstr([list2(indx2(1,i)),'; ']);
    end
    regions_cell = regions_cell';
    regions_cell2 = reshape(regions_cell,1,[]);
    region_text = cell2mat(regions_cell2);

    txt = sprintf(['SETTINGS:',...
    '\n data folder: %s ',...
    '\n number of subjects: %d ',...
    '\n data folder: %s ',...
    '\n starting time: %d ',...
    '\n window length: %d ',...
    '\n sliding interval:  %d ',...
    '\n number of time-windows:  %d ',...
    '\n number of frequencies:  %d',...
    '\n order:  %d',...
    '\n ATLAS:  %s',...
    '\n Number of parcellations:  %d',...
    '\n Parcellations:  %s'],...
    data_folder, size(subjects2analyze,1),trial_name,starting,length_of_time_windows,jumps,n_time_windows,max_freq,order2use,string(list(indx)),size(indx2,2),region_text);


    % Create the figure for the prompt screen
    fig = uifigure('Name', 'Prompt Screen', 'Position', [500, 300, 500, 300]);
    
    % Create a label for the prompt text
    lbl = uilabel(fig, 'Position', [50, 80, 400, 200], 'Text', txt);

    % Create the "OK" button
    btn_ok = uibutton(fig, 'Text', 'OK', 'Position', [50, 30, 60, 30], 'ButtonPushedFcn', @(btn, event) on_button_pressed(fig, 1,1));
    btn_restart = uibutton(fig, 'Text', 'Restart', 'Position', [120, 30, 60, 30], 'ButtonPushedFcn', @(btn, event) on_button_pressed(fig, 0,1));
    btn_cancel = uibutton(fig, 'Text', 'Cancel', 'Position', [190, 30, 60, 30], 'ButtonPushedFcn', @(btn, event) on_button_pressed(fig, 2,1));
    
    while timing~=1
    % Keep checking if the button was pressed
    pause(0.1);  % Small pause to avoid overloading the CPU
    end
end

% loads the folder
cd(data_folder)

if check_x == 1
    %% program start
    % the name of all available subject folders
    load('protocol.mat')

    % in protocol there might be entries that are not studz participants.
    % these entries generally do not have an associated anatomy
    % cleans the structure ProtocolSubject from those irrelevant entries
    count = 0;
    pos = zeros(1,1);

    for iMove = 1 : size(ProtocolSubjects.Subject,2)
        if size(ProtocolSubjects.Subject(iMove).Anatomy,1) ~= 0
            count = count + 1;
            pos(1,count) = iMove;
        end
    end    

    ProtocolSubjects.Subject = ProtocolSubjects.Subject(pos);


    % sets the list of subjects to be analyzed
    if subjects2analyze(1,1) == 0
        subjects = [1:size(ProtocolSubjects.Subject,2)];
    else
        subjects = subjects2analyze;
    end

    % this variable checks the number of iterations of the program
    participant = 0;



    c = 0;
    time_window = 1;

    %MOVES along the list of participants
    for iFile = 1 : length(subjects)

        data2save = cell(n_time_windows,4);
        % counts the number of participants
        participant = participant + 1;

        % builds a variable with the path to the folder of interest  
        folder2open = sprintf('%s\\%s', data_folder, ProtocolSubjects.Subject(subjects(iFile)).Name);   % OPENS the folder of interest

        % loads the subject folder
        cd (folder2open)

        % gets a list of all the subfolders for the participant
        subfolders2use = dir;

        %gets only folders excluding other files
        subfolders2use = subfolders2use([subfolders2use.bytes] == 0);

        % builds a variable with the path to the subfolder of interest  
        subfolder2open = sprintf('%s\\%s', subfolders2use(end-position_folder).folder, subfolders2use(end-position_folder).name);

        % OPENS the folder of interest
        cd (subfolder2open)

        % -----------------looking for the kernel
        % gets the name of the files starting with "results"
        % the kernel name is "results...KERNEL....mat"
        filesStartingWith4Kernel = dir(fullfile('results_dSPM*.*'));%%% Can be changed

        % this variable controls how many kernel are present in the folder
        % if the are more than 1 a WARNING is displayed and the last kernel
        % is used
        checkNumberOfKernel = 0; 

        % looks for the file that contain KERNEL in the name
        for iKernelFinder = 1 : size(filesStartingWith4Kernel,1)
            if strfind(filesStartingWith4Kernel(iKernelFinder).name,'KERNEL') ~= 0
                kernel = filesStartingWith4Kernel(iKernelFinder).name;
                checkNumberOfKernel = checkNumberOfKernel + 1;
            end    
        end  

        % errors and warnings about kernel selection
        if checkNumberOfKernel == 0
            error('Error. \nNo KERNEL was found')
        elseif checkNumberOfKernel > 1
            'WARNING: more than one KERNEL were found.\n\n The program used the last KERNEL\nIf this KERNEL was not the desired one cancel other KERNELs or recalculate the ernel of interest, to have it in the last position';
            KERNEL = load(kernel);
        else
            KERNEL = load(kernel);
        end

        % -----------------looking for the average file
        % gets the name of the files starting with "data_XX_average"
        filesStartingWith4Average = dir(fullfile(sprintf('data_%s_average*.*',trial_name)));%%%

        checkNumberOfAverage = size(filesStartingWith4Average,1);
        average = filesStartingWith4Average(end,1).name;

        % errors and warnings about average selection
        if checkNumberOfAverage == 0
            error('Error. \nNo average was found')
        elseif checkNumberOfAverage > 1
            'WARNING: more than one AVREAGE file were found.\n\n The program used the last average\nIf this average was not the desired one cancel the other averages or recalculate the average of interest, to have it in the last position'
            AVERAGE = load(average);
        else
            AVERAGE = load(average);
        end

        %% sFiles for Brainstorm concatenate function

        % the list of artifacts free trials is reported in the History
        % file, from the seventh position
        sFiles_temp = AVERAGE.History(7:end,3);

        % transforms the content from cell to mat format
        sFiles_temp2 = cell2mat(sFiles_temp);

        % erases the ' - ' part from each name, making it readable
        sFiles_temp3 = string(sFiles_temp2(:,4:end));

        % creates the sFiles for concatenation in brainstorm
        sFiles = cellstr(sFiles_temp3)';

        %% BRAINSTORM concatenate and duplicate
        bst_report('Start', sFiles);

        % Process: Concatenate time
        sFiles = bst_process('CallProcess', 'process_concat', sFiles, []);

        % Process: Duplicate data files: Add tag "_copy"
        sFiles = bst_process('CallProcess', 'process_duplicate', sFiles, [], ...
            'target', 1, ...  % Duplicate data files
            'tag',    '_to_be_modified');

        % Save and display report
        ReportFile = bst_report('Save', sFiles);
        bst_report('Open', ReportFile);

        %% SCRIPT 

        % gets the length of a single trial
        trial_length = size(AVERAGE.F,2);

        % modifies the time as integer numbers in milliseconds
        Time_mod = int16(AVERAGE.Time*1000);

        % gets the recording sampling rate
        sample_size_temp = double(Time_mod(1,2)-Time_mod(1,1));

        % the beginning of the segment
        % gets a list of distances from the desired value       
        distances = abs(starting-Time_mod(1,:));

        % select the value/values which is/are the closest to the desires
        % one
        closesValue = find(min(distances)==distances);

        % gets the starting point
        starting_point = closesValue(1,1);

        % informs that the selected value was different from the desired
        % one, but still the best
        if size(closesValue,2) > 1
            'WARNING: no time point corresponsed to the desired starting point.\n\n The closes value was used instead'
        end    

        % gets the list of concatenated files in the folder
        data_concat = dir(fullfile('data_concat*.*'));%%%

        % reiterate the pross for the number of desired time-windows
        for iMoving = 1 : n_time_windows

            % loads the two created concatenated files
            % the first one that won't be modified in the process
            concat1 = load(data_concat(end-1).name);

            % the second one that will be modified everz time
            concat2 = load(data_concat(end).name);

            % gets the number of artifacts-free trials
            number_of_trials = size(concat1.History,1)-6;

            % converts the time window based according to the sample size
            selection_length = double(floor(length_of_time_windows/sample_size_temp));

            % sets the parameters for the to-be-created concatenated file 
            concat2.F = concat1.F(:,1:number_of_trials*(selection_length+1)); 
            concat2.Time = concat1.Time(1,1:number_of_trials*(selection_length+1)); 


            %% CORE of the program

            for iTrial = 1 : number_of_trials
                starting_saving_point = (iTrial-1)*floor(length_of_time_windows/sample_size_temp)+1;
                ending_saving_point = (iTrial-1)*floor(length_of_time_windows/sample_size_temp)+1+selection_length;

                starting_estraction_point = (iTrial-1)*trial_length+starting_point+(iMoving-1)*jumps;
                ending_estraction_point = (iTrial-1)*trial_length+starting_point+(iMoving-1)*jumps+selection_length;

                concat2.F(:,starting_saving_point:ending_saving_point) = concat1.F(:,starting_estraction_point:ending_estraction_point);
            end

            %% BRAINSTOR script 

            save(data_concat(end).name,'-struct', 'concat2');
            db_reload_subjects(iFile)

            file_name2 = sprintf('link|%s\\%s\\%s|%s\\%s\\%s', subfolders2use(end-position_folder).folder,subfolders2use(end-position_folder).name,kernel,subfolders2use(end-position_folder).folder,subfolders2use(end-position_folder).name,data_concat(end).name);
            %Script generated by Brainstorm (06-Aug-2022)

            % Input files
            sFiles = {file_name2};

            % Start a new report
            bst_report('Start', sFiles);

            % Process: Bivariate Granger causality (spectral) NxN
            sFiles = bst_process('CallProcess', 'process_spgranger1n', sFiles, [], ...
                'timewindow',   [], ...
                'scouts',       {altas, regions}, ...
                'flatten',      0, ...
                'scouttime',    'after', ...  % after connectivity
                'scoutfunc',    'mean', ...  % PCA 
                'scoutfuncaft', 'mean', ...  % Mean 
                'pcaedit',      struct(...
                     'Method',         'pcaa', ...
                     'Baseline',       [NaN, NaN], ...
                    'DataTimeWindow', [concat2.Time(1), concat2.Time(end)], ...
                    'RemoveDcOffset', 'none'), ...
                'removeevoked', 0, ...
                'grangerorder', order2use, ...
                'maxfreqres',   3, ...
                'maxfreq',      max_freq-0.1, ...
                'outputmode',   1);  % Save individual results (one file per input file)

            % Save and display report
            ReportFile = bst_report('Save', sFiles);
            bst_report('Open', ReportFile);
            % bst_report('Export', ReportFile, ExportDir);
            % bst_report('Email', ReportFile, username, to, subject, isFullReport);

            saved_name = dir(fullfile('timefreq_connectn_spgranger*.*'));%%%
            file_data = load(saved_name(end).name);

            filesStartingWith4Concat = dir(fullfile(sprintf('data_concat_*.*',trial_name)));%%%

            data2save(iMoving,1) =  {iMoving};
            data2save(iMoving,2) =  {file_data.Comment};
            data2save(iMoving,3) =  {starting_point+(iMoving-1)*jumps};
            data2save(iMoving,4) =  {starting_point+selection_length+(iMoving-1)*jumps};
            data2save(iMoving,5) =  {Time_mod(cell2mat(data2save(iMoving,3)))};
            data2save(iMoving,6) =  {Time_mod(cell2mat(data2save(iMoving,4)))};
            data2save(iMoving,7) =  {file_data.DataFile};
            data2save(iMoving,8) =  {saved_name(end).name};
            end

            area_regions = cell(size(indx2,2),3);
            for i = 1 : size(indx2,2)
                area_regions(i,1) = {atlas};
                area_regions(i,2) = {Scouts(indx2(i)).Label};
                area_regions(i,3) = {size(Scouts(indx2(i)).Vertices,2)};
            end    

        output.input_settings(1,:) = string(sprintf('experiment folder: %s',data_folder));
        output.input_settings(2,:) = string(sprintf('trial: %s',trial_name));
        output.input_settings(3,:) = string(sprintf('first time point: %d',starting));
        output.input_settings(4,:) = string(sprintf('time window length: %d',length_of_time_windows));
        output.input_settings(5,:) = string(sprintf('time window slide: %d',jumps));
        output.input_settings(6,:) = string(sprintf('number of time windows: %d',n_time_windows));
        output.input_settings(7,:) = string(sprintf('top frequency: %d',max_freq));
        output.input_settings(8,:) = string(sprintf('Granger causality: %d',order2use));

        output.current(1,:) = string(sprintf('subject: %s', folder2open));
        output.current(2,:) = string(sprintf('folder for the analysis: %s', subfolder2open));
        output.current(3,:) = string(sprintf('data with concatenated trials (whole): %s', filesStartingWith4Concat(end-1).name));
        output.current(4,:) = string(sprintf('data with concatenated trials (segmented): %s', filesStartingWith4Concat(end).name));

        output.design_description(1,:) = string(sprintf('number of artifact-free trials: %d', iTrial));
        output.design_description(2,:) = string(sprintf('number of time points in  the trial: %d', length(Time_mod)));
        output.design_description(3,:) = string(sprintf('trial starting time: %d', Time_mod(1)));
        output.design_description(4,:) = string(sprintf('trial ending time: %d', Time_mod(end)));
        output.design_description(5,:) = string(sprintf('sampling frequency: %d', floor(1000/(Time_mod(2)-Time_mod(1)))));
        output.design_description(6,:) = string(sprintf('name of concatenated data (whole): %s', concat1.Comment));
        output.design_description(7,:) = string(sprintf('number of time points in the concatenated data (whole): %d', length(concat1.Time)));
        output.design_description(8,:) = string(sprintf('name of concatenated data (segmented): %s', concat2.Comment));
        output.design_description(9,:) = string(sprintf('number of time points in the concatenated data (segmented): %d', length(concat2.Time)));

        output.frequencies = file_data.Freqs;

        output.region = area_regions;
        f = find(folder2open=='\');
        subject_name = folder2open(1,f+1:end);

        % Get the current date and time
        currentTime = datetime('now', 'Format', 'yyyy-MM-dd_HH-mm-ss');

        % Create the file name using the current time
        fileName = sprintf('%s/Granger_causality_%s_%s.mat', current_folder,subject_name,currentTime);

        % Save the structure with the generated file name
        save(fileName, 'output');

    end
end    