function on_button_pressed(fig, button_code, button_code2)
% Function to handle the button press and return the corresponding code
    % Store the code globally
    % Assign the button code to the base workspace
    assignin('base', 'check_x', button_code);
    assignin('base', 'timing', button_code2);

% Close the figure
    close(fig); 
    
end